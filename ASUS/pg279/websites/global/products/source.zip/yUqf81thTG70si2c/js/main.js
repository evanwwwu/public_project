 $(function() {
 	var mobile = "pg279q";
 	var main = {
 		init:function(){
 			$(".videolink").asus_video($("#"+mobile+"-warp"));
 			this.warp_size();
 			this.mobile_menu();
 			this.light_ctr();
 			$("#overview-aside-nav ul").navscroll({
 				sec: 1000,
 				url_hash: false,
 				head_hight:60
 			});
 			$("#"+mobile+"-main .mainnav").navscroll({
 				sec: 1000,
 				url_hash: false,
 				head_hight:60
 			});
 			$("#"+mobile+"-control .control_bar").css({
 				"top":$("#"+mobile+"-control .mainwarp .on .con_detail").height()+120+((690-$("#"+mobile+"-control .mainwarp .on .con_detail").height())/2)
 			});
 		},
 		resize:function(){
 			this.warp_size();
 			this.mobile_menu();
 			$("#"+mobile+"-control .control_bar").css({
 				"top":$("#"+mobile+"-control .mainwarp .on .con_detail").height()+120+((690-$("#"+mobile+"-control .mainwarp .on .con_detail").height())/2)
 			});
 		},
 		warp_size:function(){
 			$("#"+mobile+"-warp").css({
 				width:$(window).width(),
 				"margin-left": ($("#special-sectionOverview, #sectionOverview").width() - $(window).width()) / 2
 			});
 		},
 		mobile_menu:function(){
 			if(window.innerWidth<=768){
 				$(window).scroll(function(){
 					if(window.innerWidth<=768){
 						var ws = $(window).scrollTop();
 						var mt = $("#"+mobile+"-warp").offset().top;
 						if(ws>mt){
 							$("#"+mobile+"-main").css({
 								position: "fixed",
 								top:$("#overview-top-nav").height()
 							});
 						}
 						else{
 							$("#"+mobile+"-main").css({
 								position: "relative",
 								top:0
 							});
 						}
 					}
 				});
 				$("#"+mobile+"-warp .mobile_nav>.m_btn").unbind("click");
 				$("#"+mobile+"-warp .mobile_nav>.m_btn").click(function(){
 					$("#"+mobile+"-warp .mainnav").slideToggle();
 				});
 				$("#"+mobile+"-warp .mainnav>.znav").unbind("click");
 				$("#"+mobile+"-warp .mainnav>.znav").click(function(){
 					$("#"+mobile+"-warp .mainnav").slideToggle();
 				});
 			}
 			else{
 				$("#"+mobile+"-main").removeAttr("style");
 				$("#"+mobile+"-warp .mainnav").show();
 			}
 		},
 		hd_draggable:function(){
 			var scr = $("#"+mobile+"-warp .screen");
 			scr.find(".ctr_line").draggable({
 				axis: "x",
 				containment: "#"+mobile+"-desktop",
 				scroll: false,
 				drag: function( event, ui ) {
 					console.log(ui.position.left);
 					var cor = ui.position.left;
 					var tw = scr.width();
 					scr.find(".desktop .left").width(50+(cor/tw * 100)+"%");
 				}
 			});
 		},
 		change_box:function(){
 			var box = $("#"+mobile+"-warp .change_box");
 			box.find(".btns .box_btn").each(function(){
 				$(this).click(function(){
 					var inx = box.find(".btns .box_btn").index($(this));
 					box.find(".btns .box_btn").removeClass("on");
 					box.find(".btns .box_btn").eq(inx).addClass("on");
 					box.find(".imgs>img").removeClass("on");
 					box.find(".imgs>img").eq(inx).addClass("on");
 				});
 			});
 		},
 		sildeshow:function(){
 			var clickstop = true;
 			var sildeshow = $("#"+mobile+"-warp .sildeshow");
 			var btn_w = sildeshow.find(".titles").width();
 			if(window.innerWidth >　768){
 				var title_w = 112;
 				sildeshow.find(".titles .mask").css({"padding-left":title_w*2,"padding-right":title_w*2});
 			}
 			else{
 				var title_w = 260;
 			}
 			sildeshow.find(".titles .mask").width(title_w*6);
 			sildeshow.find(".infos .info").width(sildeshow.find(".infos").width());
 			sildeshow.find(".infos .mask").width(sildeshow.find(".infos").width()*6);

 			var finx = sildeshow.find(".infos .info").index(sildeshow.find(".infos .info.on"));
 			sildeshow.find(".infos .mask").css("margin-left",-finx * sildeshow.find(".infos").width());
 			if(window.innerWidth < 768){
 				sildeshow.find(".arr_btn").css({"bottom":sildeshow.find(".infos").height()});
 			}
 			sildeshow.find(".arr_btn .next").click(function(){
 				if(clickstop){
 					clickstop = false;
 					var inx = sildeshow.find(".titles .t_btn").index(sildeshow.find(".titles .t_btn.on"));
 					sildeshow.find(".titles .t_btn").removeClass("on");
 					sildeshow.find(".infos .info").removeClass("on");
 					sildeshow.find(".items .item ").removeClass("on");

 					sildeshow.find(".titles .mask").animate({
 						"margin-left":"-="+title_w
 					},500,function(){
 						sildeshow.find(".titles .t_btn").eq(inx+1).addClass("on");
 					});

 					sildeshow.find(".infos .mask").animate({
 						"margin-left":"-="+sildeshow.find(".infos").width()
 					},500,function(){
 						sildeshow.find(".infos .info").eq(inx+1).addClass("on");
 						clickstop = true;
 					});
 					sildeshow.find(".items .item ").eq(inx+1).addClass("on");
 					check_btn(inx+1);
 				}
 			});
 			sildeshow.find(".arr_btn .pre").click(function(){
 				if(clickstop){
 					clickstop = false;
 					var inx = sildeshow.find(".titles .t_btn").index(sildeshow.find(".titles .t_btn.on"));
 					sildeshow.find(".titles .t_btn").removeClass("on");
 					sildeshow.find(".infos .info").removeClass("on");
 					sildeshow.find(".items .item ").removeClass("on");

 					sildeshow.find(".titles .mask").animate({
 						"margin-left":"+="+title_w
 					},500,function(){
 						sildeshow.find(".titles .t_btn").eq(inx-1).addClass("on");
 					});

 					sildeshow.find(".infos .mask").animate({
 						"margin-left":"+="+sildeshow.find(".infos").width()
 					},500,function(){
 						sildeshow.find(".infos .info").eq(inx-1).addClass("on");
 						clickstop = true;
 					});
 					sildeshow.find(".items .item ").eq(inx-1).addClass("on");
 					check_btn(inx-1);
 				}
 			});
 			check_btn = function(inx){
 				console.log(inx);
 				if(inx==0){
 					sildeshow.find(".pre").hide();
 				}else{
 					sildeshow.find(".pre").show();
 				}
 				if(inx==5){
 					sildeshow.find(".next").hide();
 				}else{
 					sildeshow.find(".next").show();
 				}
 			}
 		},
 		light_ctr:function(){
 			var light = $("#"+mobile+"-warp .light_ctr");
 			light.find(".ctr .l").click(function(){
 				var inx =light.find(".ctr .l").index($(this));
 				light.find(".ctr .l").removeClass("on");
 				light.find(".pics>img").removeClass("on");
 				light.find(".ctr .l").eq(inx).addClass("on");
 				light.find(".pics>img").eq(inx).addClass("on");
 			});
 		}
 	}
 	main.init();
 	main.hd_draggable();
 	main.change_box();
 	main.sildeshow();
 	setTimeout(function(){$("#"+mobile+"-warp .reel-indicator").wrap('<div class="reel-indicator-bar" />');});
 	$(window).resize(function(){
 		location = location;
 	});
 });

