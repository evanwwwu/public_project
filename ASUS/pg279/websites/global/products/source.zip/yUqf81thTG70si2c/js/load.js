﻿(function(){
	var online = /asus\.com/.test( window.location.hostname ), path = online?'/':'';
	document.write( '<link rel="stylesheet" href="' + path + 'websites/global/products/yUqf81thTG70si2c/css/style.css">');
	document.write( '<script src="' + path + 'websites/global/products/yUqf81thTG70si2c/js/plu/jquery.reel-min.js"></script>');
	document.write( '<script src="' + path + 'websites/global/products/yUqf81thTG70si2c/js/plu/jquery.navscroll.min.js"></script>');
	document.write( '<script src="' + path + 'websites/global/products/yUqf81thTG70si2c/js/plu/jquery-ui.min.js"></script>');
	document.write( '<script src="' + path + 'websites/global/products/yUqf81thTG70si2c/js/plu/video.js"></script>');
	document.write( '<script src="' + path + 'websites/global/products/yUqf81thTG70si2c/js/modernizr.js"></script>');
	document.write( '<script src="' + path + 'websites/global/products/yUqf81thTG70si2c/js/main.min.js"></script>');
})();

