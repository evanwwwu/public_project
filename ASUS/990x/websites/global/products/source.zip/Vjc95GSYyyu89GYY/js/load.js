﻿(function(){
	var online = /asus\.com/.test( window.location.hostname ), path = online?'/':'';
	document.write( '<link rel="stylesheet" href="' + path + 'websites/global/products/Vjc95GSYyyu89GYY/css/style.css">');
	document.write( '<script src="' + path + 'websites/global/products/Vjc95GSYyyu89GYY/js/plu/plugin.js"></script>');
	document.write( '<script src="' + path + 'websites/global/products/Vjc95GSYyyu89GYY/js/main.js"></script>');
})();
